<p>This is a blank stub file. Copy it, rename it same as the target host name (eg, for http://amazon.com/ name the file amazon.php), and start editing ...</p>
<?php
$test_url = 'http://www.google.com';
$arrXpaths = array(
					'Product Name' => '//title',
					'UPC' => '',
					'SKU' => '',
					'Image' => '',
					'Retail Price' => '',
					'Price' => ''
				  );
require('includes/main.php');
?>
